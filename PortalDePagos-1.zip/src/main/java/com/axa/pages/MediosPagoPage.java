package com.axa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


import javax.swing.text.Element;
import javax.xml.xpath.XPath;
import java.util.Scanner;

public class MediosPagoPage extends BasePageObject{

    //Seleccionar Tipo Tarjeta Visa
    @FindBy(xpath="//div[@class=\"select-items\"]//following::img[@src=\"/pagosenlinea/Content/images/site/autos/visa.png\"]")
    private WebElement selectTarjetaVisa;

    //Botón Pagar
    @FindBy(xpath="//div[@class=\"select-items\"]//following::div[@class=\"col-sm-offset-6 col-sm-3 col-xs-offset-0 col-xs-12\"]")
    private WebElement buttonPagar;

    public MediosPagoPage(WebDriver driver) {
        super(driver);
    }

    public void pagoExitosoTarjetaVisa(){

        selectTarjetaVisa.click();
        buttonPagar.click();

    }
}
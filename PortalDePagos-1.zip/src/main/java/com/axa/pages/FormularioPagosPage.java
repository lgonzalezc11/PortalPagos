package com.axa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


import javax.swing.text.Element;
import java.util.Scanner;

public class FormularioPagosPage extends BasePageObject{

    private static final String Nombres = "Leidy";
    private static final String Apellidos ="Gonzalez";
    private static final String DocumentoIdentidad="123456789";
    private static final String Telefono="1100456";
    private static final String Correo="leidy.gonzalez@axacolpatria.co";
    private static final String Direccion="carrera 5 # 3-10";

    //Ingresar Nombres del Pagador
    @FindBy(id = "Nombre")
    private WebElement inputNombres;

    //Ingresar Apellidos del Pagador
    @FindBy(id = "Apellido")
    private WebElement inputApellidos;

    //Seleccionar Tipo Documento
    @FindBy(xpath="//select[@id='TipoDocumento']//following::option[contains(text(),'CEDULA')]")
    private WebElement selectTipoDoc;

    //Ingresar Documento del Pagador
    @FindBy(id = "Documento")
    private WebElement inputDocumentoIdentidad;

    //Ingresar Telefono del Pagador
    @FindBy(id = "Telefono")
    private WebElement inputTelefono;

    //Ingresar Correo del Pagador
    @FindBy(id = "Correo")
    private WebElement inputCorreo;

    //Seleccionar Ciudad
    @FindBy(xpath="//select[@id='Ciudad']//following::option[contains(text(),'BOGOTA / BOGOTA')]")
    private WebElement selectCiudad;

    //Ingresar Dirección del Pagador
    @FindBy(id = "Direccion")
    private WebElement inputDireccion;

    //Seleccionar Check de Condiciones Producto
    @FindBy(xpath="//label[@class=\"subtitle\"]//following::label[@for=\"checkAxa\"]")
     private WebElement selectCheckAXA;


    public FormularioPagosPage(WebDriver driver) {
        super(driver);
    }

    public void llenarFormularioPago(){
        inputNombres.clear();
        inputNombres.sendKeys(Nombres);
        inputApellidos.clear();
        inputApellidos.sendKeys(Apellidos);
        selectTipoDoc.click();
        inputDocumentoIdentidad.clear();
        inputDocumentoIdentidad.sendKeys(DocumentoIdentidad);
        inputTelefono.clear();
        inputTelefono.sendKeys(Telefono);
        inputCorreo.clear();
        inputCorreo.sendKeys(Correo);
        selectCiudad.click();
        inputDireccion.clear();
        inputDireccion.sendKeys(Direccion);
        selectCheckAXA.click();
    }



}




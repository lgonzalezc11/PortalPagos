package com.axa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PagosRecurrentesPage extends BasePageObject{

    //Botón Pagos Recurrentes
    @FindBy(xpath="//h1[contains(text(),'Pagos en línea')]//following::h4[contains(text(),'Pagos recurrentes')]")
    private WebElement butonPagosRecurrentes;

    //Clic Tipo Documento
    @FindBy(id="TipoDocumento")
    private WebElement clicTipoDoc;

    //Seleccionar Tipo Documento
    @FindBy(xpath="//select[@id='TipoDocumento']//following::option[contains(text(),'CEDULA')]")
    private WebElement selectTipoDoc;

    //Ingresar Numero de Documento
    @FindBy(xpath="//label[contains(text(),'Documento de Identidad')]//following::input[@id='Documento']")
    private WebElement inputNumeroDoc;

    //Seleccionar Tipo Producto
    @FindBy(xpath="//label[contains(text(),'Selecciona el tipo de producto')]//following::h4[contains(text(),'SALUD')]")
    private WebElement selectTipoProducto;

    //Seleccionar Tipo Plan
    @FindBy(xpath="//h4[contains(text(),'SALUD')]//following::label[contains(text(),'Medicina Prepagada')]")
    private WebElement selectTipoPlan;

    //Ingresar Numero de Poliza
    @FindBy(xpath="//label[@class='labelhalf']//following::input[@id='NumeroReferencia']")
    private WebElement inputNumeroPoliza;

    //Botón Consultar
    @FindBy(xpath="//label[@class='labelhalf']//following::button[@id='btnConsultar']")
    private WebElement butonConsultar;


    public PagosRecurrentesPage(WebDriver driver) {
        super(driver);
    }

    public static String urlActual(){
        return driver.getCurrentUrl();
    }

    public void abrirPagosRecurrentes(){
        butonPagosRecurrentes.click();
    }
    public void seleccionPolizaPagar(String numDoc, String numPoliza){
        clicTipoDoc.click();
        selectTipoDoc.click();
        inputNumeroDoc.click();
        inputNumeroDoc.clear();
        inputNumeroDoc.sendKeys(numDoc);
        selectTipoProducto.click();
        selectTipoPlan.click();
        inputNumeroPoliza.click();
        inputNumeroPoliza.clear();
        inputNumeroPoliza.sendKeys(numPoliza);
        butonConsultar.click();

    }


}


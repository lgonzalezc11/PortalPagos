 package com.axa;

import com.axa.pages.FormularioPagosPage;
import com.axa.pages.MediosPagoPage;
import com.axa.pages.PagosRecurrentesPage;
import org.testng.Assert;
import org.testng.annotations.*;

public class PagosRecurrentesTest extends BaseFuncionalTest{

    @Test()
    //Pago Recurrente con tipo doc Cedula, poliza de salud MMP, Medio pago Tarjeta VISA Exitoso
    public void pagosRecurrentes(){
        driver.get("http://dc2tvaweb7.uinversion.colpatria.com:81/pagosenlinea/");
        PagosRecurrentesPage pagosRecurrentesPage = new PagosRecurrentesPage(driver);
        FormularioPagosPage formularioPagosPage = new FormularioPagosPage(driver);
        MediosPagoPage mediosPagoPage = new MediosPagoPage(driver);
        pagosRecurrentesPage.abrirPagosRecurrentes();
        pagosRecurrentesPage.seleccionPolizaPagar("45646004", "132803700000");
        formularioPagosPage.llenarFormularioPago();
        mediosPagoPage.pagoExitosoTarjetaVisa();

        String urlActual = PagosRecurrentesPage.urlActual();
        String urlEsperada = "http://dc2tvaweb7.uinversion.colpatria.com:81/pagosenlinea/ResumenPagosD3#no-back-button";
        Assert.assertEquals(urlEsperada, urlActual);
    }
}
